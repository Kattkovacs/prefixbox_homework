var checkbox = document.querySelector(".sale");
var elementsChildPrice = document.getElementsByClassName("product-price");

checkbox.addEventListener('change', function() {
  if (this.checked) {
    for(let i = 0 ; i < elementsChildPrice.length ; i++){
        elementsChildPrice[i].parentNode.childElementCount == 2 ? 
        elementsChildPrice[i].parentNode.parentNode.style.display = "none" :
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block";        
    }
  } else {
    for(let i = 0 ; i < elementsChildPrice.length ; i++){
        elementsChildPrice[i].parentNode.parentNode.style.display = "none" ?
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block" :
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block";        
    }
  }
});

var orderSelection = document.querySelectorAll(".order");
const frag = document.createDocumentFragment();
const list = document.querySelector(".products");
const items = document.querySelectorAll(".product");

const sortedListNumeric = Array.from(items).sort(function(a, b) {
  const c = a.firstChild.nextSibling.childNodes[1].text,
    d = b.firstChild.nextSibling.childNodes[1].text;
  return c < d ? -1 : c > d ? 1 : 0;
});

const sortedListAlphabetical = Array.from(items).sort(function(a, b) {
  const c = a.children[1].childNodes[1].innerHTML,
    d = b.children[1].childNodes[1].innerHTML;
  return c < d ? -1 : c > d ? 1 : 0;
});

for (let i = 0; i < orderSelection.length; i++) {
    orderSelection[i].addEventListener("click", function (e) {
       
      if(this.value == "0") { 
        (() => {
          for (let item of sortedListNumeric) {
            frag.appendChild(item);
          }
          list.appendChild(frag);
        })();
      };

      if(this.value == "1"){ 
        (() => {
          sortedListNumeric.reverse();
          for (let item of sortedListNumeric) {
            frag.appendChild(item);
          }
          list.appendChild(frag);
        })();
      };

      if(this.value == "2") {
        (() => {
          for (let item of sortedListAlphabetical) {
            frag.appendChild(item);
          }
          list.appendChild(frag);
        })();
      };
      if(this.value == "3") {
        sortedListAlphabetical.reverse();
        (() => {
          for (let item of sortedListAlphabetical) {
            frag.appendChild(item);
          }
          list.appendChild(frag);
        })();
      };
    });
};

