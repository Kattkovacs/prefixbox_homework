var checkbox = document.querySelector(".sale");
var elementsChildPrice = document.getElementsByClassName("product-price");

checkbox.addEventListener('change', function() {
  if (this.checked) {
    for(var i = 0 ; i < elementsChildPrice.length ; i++){
        elementsChildPrice[i].parentNode.childElementCount == 2 ? 
        elementsChildPrice[i].parentNode.parentNode.style.display = "none" :
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block";        
    }
  } else {
    for(let i = 0 ; i < elementsChildPrice.length ; i++){
        elementsChildPrice[i].parentNode.parentNode.style.display = "none" ?
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block" :
        elementsChildPrice[i].parentNode.parentNode.style.display = "inline-block";        
    }
  }
});

var orderSelection = document.querySelectorAll(".order");

for (var i = 0; i < orderSelection.length; i++) {
    orderSelection[i].addEventListener("click", function (e) {
        if(this.value == "0") console.log("0 selected");
        if(this.value == "1") console.log("1 selected");
        if(this.value == "2") console.log("2 selected");
        if(this.value == "3") console.log("3 selected");
    });
};

